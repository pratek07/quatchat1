from django import forms

class GenerateForm(forms.Form):
    COUNT_CHOICES = [(50,'50'),(75,'75'),(100,'100'),(150,'150')]
    count = forms.ChoiceField(choices=COUNT_CHOICES)

class UploadForm(forms.Form):
    file = forms.FileField()
