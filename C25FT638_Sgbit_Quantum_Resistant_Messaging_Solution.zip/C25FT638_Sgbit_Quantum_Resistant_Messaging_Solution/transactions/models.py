from django.db import models
from django.conf import settings

class Transaction(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    account_number = models.CharField(max_length=20)
    credit_card_number = models.CharField(max_length=20)
    amount = models.FloatField()
    currency = models.CharField(max_length=8, default='USD')
    timestamp = models.DateTimeField()
    merchant = models.CharField(max_length=120)
    category = models.CharField(max_length=64)  # e.g. groceries, travel
    label = models.CharField(max_length=32)  # normal | identity_theft | money_laundering | credit_card_fraud | account_takeover
    meta = models.JSONField(default=dict, blank=True)

# transactions/models.py
from django.conf import settings
from django.db import models

class FraudAlert(models.Model):
    TYPE_CHOICES = [
        ('identity_theft', 'Identity Theft'),
        ('money_laundering', 'Money Laundering'),
        ('credit_card_fraud', 'Credit Card Fraud'),
        ('account_takeover', 'Account Takeover'),
    ]
    SEVERITY = [('low','Low'), ('medium','Medium'), ('high','High')]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='fraud_alerts')
    created_at = models.DateTimeField(auto_now_add=True)
    txn_timestamp = models.DateTimeField(null=True, blank=True)

    # masked identifiers
    account_number = models.CharField(max_length=32, blank=True)
    credit_card_number = models.CharField(max_length=32, blank=True)

    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    merchant = models.CharField(max_length=255, blank=True)
    category = models.CharField(max_length=64, blank=True)

    type = models.CharField(max_length=32, choices=TYPE_CHOICES)
    reason = models.TextField(blank=True)
    suggestions = models.TextField(blank=True)
    severity = models.CharField(max_length=16, choices=SEVERITY, default='medium')

    source = models.CharField(max_length=32, default='upload')  # upload, realtime, etc.
    status = models.CharField(max_length=16, default='open', choices=[('open','Open'),('reviewing','Reviewing'),('closed','Closed')])

    def __str__(self):
        return f"{self.user} • {self.type} • {self.amount} • {self.txn_timestamp:%Y-%m-%d %H:%M}"
