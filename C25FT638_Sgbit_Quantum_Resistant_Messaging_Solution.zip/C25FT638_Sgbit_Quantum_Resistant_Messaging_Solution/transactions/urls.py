from django.urls import path
from . import views

app_name = "transactions"
urlpatterns = [
    path('generate/', views.generate_dataset, name='generate'),
    path('upload/', views.upload_and_analyze, name='upload'),
]
