from cryptography.fernet import Fernet, InvalidToken
from django.conf import settings

fernet = Fernet(settings.ENCRYPTION_KEY.encode() if isinstance(settings.ENCRYPTION_KEY, str) else settings.ENCRYPTION_KEY)

def encrypt_str(val: str) -> str:
    if val is None:
        return None
    if isinstance(val, str):
        valb = val.encode()
    else:
        valb = str(val).encode()
    return fernet.encrypt(valb).decode()

def decrypt_str(val: str) -> str:
    if val is None:
        return None
    try:
        return fernet.decrypt(val.encode()).decode()
    except (InvalidToken, AttributeError):
        # if it's not encrypted yet, return as-is
        return val
