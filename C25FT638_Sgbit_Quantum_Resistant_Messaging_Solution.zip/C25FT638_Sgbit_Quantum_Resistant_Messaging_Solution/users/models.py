from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from django.conf import settings
from .fields import EncryptedCharField, EncryptedTextField
from django.core.validators import RegexValidator

class User(AbstractUser):
    # Only username + email used; name fields left blank (we store encrypted in profile)
    email = models.EmailField(unique=True)
    REQUIRED_FIELDS = ['email']

class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    first_name = EncryptedCharField(max_length=255, blank=True, null=True)
    middle_name = EncryptedCharField(max_length=255, blank=True, null=True)
    last_name = EncryptedCharField(max_length=255, blank=True, null=True)
    phone = EncryptedCharField(
        max_length=32, blank=True, null=True, validators=[RegexValidator(r'^\+?\d{7,15}$')])
    dob_iso = EncryptedCharField(max_length=20, blank=True, null=True)  # store YYYY-MM-DD as encrypted string
    gender = EncryptedCharField(max_length=10, blank=True, null=True)
    random_letter_index = EncryptedCharField(max_length=4, blank=True, null=True)  # '1'..'26'
    secret_code_hints = models.TextField(blank=True, null=True)  # NOT encrypted by spec
    profile_edit_key = EncryptedCharField(max_length=64, blank=True, null=True)  # special key for profile edits

    def __str__(self):
        return f"Profile({self.user.username})"

class OTP(models.Model):
    PURPOSES = [
        ('register','Register'),
        ('login','Login'),
        ('profile_edit','Profile Edit'),
        ('reset_secret','Reset Secret'),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    code = models.CharField(max_length=6)
    purpose = models.CharField(max_length=20, choices=PURPOSES)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    used = models.BooleanField(default=False)

    def is_valid(self):
        return (not self.used) and timezone.now() < self.expires_at

class UserSession(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    login_at = models.DateTimeField()
    logout_at = models.DateTimeField(blank=True, null=True)
    duration_seconds = models.PositiveIntegerField(blank=True, null=True)

    @classmethod
    def start_session(cls, user):
        cls.objects.create(user=user, login_at=timezone.now())

    @classmethod
    def end_last_session(cls, user):
        last = cls.objects.filter(user=user, logout_at__isnull=True).order_by('-login_at').first()
        if last:
            last.logout_at = timezone.now()
            last.duration_seconds = int((last.logout_at - last.login_at).total_seconds())
            last.save()
