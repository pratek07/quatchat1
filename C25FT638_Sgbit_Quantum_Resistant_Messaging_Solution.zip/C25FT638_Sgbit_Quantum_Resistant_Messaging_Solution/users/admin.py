from django.contrib import admin
from django.contrib.auth.models import Group
from .models import User, Profile, OTP, UserSession
from transactions.models import Transaction, FraudAlert

# Remove default Groups from admin
admin.site.unregister(Group)

# Rename the Django admin
admin.site.site_header = "Threat Bank AI"
admin.site.site_title = "Threat Bank AI Admin"
admin.site.index_title = "Dashboard"

# ------------------ User / Profile / OTP / Sessions ------------------
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_active', 'is_staff')
    search_fields = ('username', 'email')


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'secret_code_hints')


@admin.register(OTP)
class OTPAdmin(admin.ModelAdmin):
    list_display = ('user', 'purpose', 'code', 'created_at', 'expires_at', 'used')
    list_filter = ('purpose', 'used')


@admin.register(UserSession)
class UserSessionAdmin(admin.ModelAdmin):
    list_display = ('user', 'login_at', 'logout_at', 'duration_seconds')


# ------------------ Transaction ------------------
@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('user', 'account_number', 'credit_card_number', 'amount', 'currency', 'timestamp', 'merchant', 'category', 'label')
    list_filter = ('currency', 'category', 'label')
    search_fields = ('user__username', 'merchant', 'account_number', 'credit_card_number')
    ordering = ('-timestamp',)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


# ------------------ FraudAlert ------------------
@admin.register(FraudAlert)
class FraudAlertAdmin(admin.ModelAdmin):
    list_display = ('user', 'type', 'severity', 'amount', 'merchant', 'category', 'txn_timestamp', 'status', 'created_at')
    list_filter = ('type', 'severity', 'status', 'source')
    search_fields = ('user__username', 'merchant', 'account_number', 'credit_card_number', 'reason')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
