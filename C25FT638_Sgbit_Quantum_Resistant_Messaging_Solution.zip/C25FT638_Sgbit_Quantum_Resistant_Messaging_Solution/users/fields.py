from django.db import models
from .encryption import encrypt_str, decrypt_str

class EncryptedTextField(models.TextField):
    def from_db_value(self, value, expression, connection):
        if value is None:
            return value
        return decrypt_str(value)
    def get_prep_value(self, value):
        if value is None:
            return None
        return encrypt_str(value)

class EncryptedCharField(models.CharField):
    def from_db_value(self, value, expression, connection):
        if value is None:
            return value
        return decrypt_str(value)
    def get_prep_value(self, value):
        if value is None:
            return None
        return encrypt_str(value)

class EncryptedDateField(models.DateField):
    def from_db_value(self, value, expression, connection):
        # store as iso string
        if value is None:
            return value
        try:
            return decrypt_str(value)
        except Exception:
            return value
    def to_python(self, value):
        return value  # return the decrypted iso string
    def get_prep_value(self, value):
        if value is None:
            return None
        return encrypt_str(str(value))
