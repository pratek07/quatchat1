import random
from django.conf import settings

# def build_secret_code(first_name, dob_iso, phone, gender, random_letter_index):
#     # Pattern: a(4 lower) + b(2 YY) + c(2 letter repeated) + m(2 MM) + p(5 last) + g(1)
#     a = (first_name or "xxxx").lower()[:4].ljust(4,'x')
#     year = (dob_iso or "2000-01-01")[:4]
#     month = (dob_iso or "2000-01-01")[5:7]
#     b = year[-2:]
#     try:
#         idx = int(str(random_letter_index).strip())
#     except (TypeError, ValueError):
#         idx = 1
#     idx = max(1, min(26, idx))
#     idx = max(1, min(26, idx))
#     letter = settings.SECRET_CODE_LETTERS[idx-1]
#     c = letter * 2
#     m = month
#     p = (phone or "00000")[-5:].rjust(5,'0')
#     g = (gender or "O")[:1].upper()
#     code = f"{a}{b}{c}{m}{p}{g}"
#     return code[:16]

def build_secret_code(first_name, dob_iso, phone, gender, random_letter_index):
    # a: first 2 lowercase chars from first name
    a = (first_name or "xx").lower()[:2].ljust(2, 'x')

    # b: last 2 digits of year
    year = (dob_iso or "2000-01-01")[:4]
    b = year[-2:]

    # c: single random letter from allowed list
    try:
        idx = int(str(random_letter_index).strip())
    except (TypeError, ValueError):
        idx = 1
    idx = max(1, min(26, idx))
    letter = settings.SECRET_CODE_LETTERS[idx - 1]
    c = letter

    # m: month MM
    m = (dob_iso or "2000-01-01")[5:7]

    # p: last 2 digits of phone
    p = (phone or "00")[-2:].rjust(2, '0')

    # g: first letter of gender uppercase
    g = (gender or "O")[:1].upper()

    # exactly 10 chars
    code = f"{a}{b}{c}{m}{p}{g}"
    return code


def secret_hints(first_name, dob_iso, phone, gender, random_letter_index):
    year = (dob_iso or "2000-01-01")[:4]
    month = (dob_iso or "2000-01-01")[5:7]
    try:
        idx = int(str(random_letter_index).strip())
    except (TypeError, ValueError):
        idx = 1
    idx = max(1, min(26, idx))
    idx = max(1, min(26, idx))
    letter = settings.SECRET_CODE_LETTERS[idx-1]
    return [
        "first 4 letters of your first name (lowercase)",
        "last 2 digits of your birth year",
        f"the letter you picked ({idx}→{letter}) repeated twice",
        "your birth month in MM format",
        "last 5 digits of your phone number",
        "first letter of your gender (M/F/O)",
    ]
