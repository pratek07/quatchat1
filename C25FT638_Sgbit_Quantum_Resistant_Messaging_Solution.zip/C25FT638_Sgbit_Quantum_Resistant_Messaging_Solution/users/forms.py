from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Profile
from django.core.validators import RegexValidator

class RegisterForm(UserCreationForm):
    # username + password inherited; add custom fields
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=255)
    middle_name = forms.CharField(max_length=255, required=False)
    last_name = forms.CharField(max_length=255)
    phone = forms.CharField(max_length=15, validators=[RegexValidator(r'^\+?\d{7,15}$')])
    dob = forms.DateField(widget=forms.DateInput(attrs={'type':'date'}))
    gender = forms.ChoiceField(choices=[('M','Male'),('F','Female'),('O','Other')])
    random_letter_index = forms.IntegerField(min_value=1, max_value=26, help_text="Pick a number 1-26")

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username','email','password1','password2','first_name','middle_name','last_name','phone','dob','gender','random_letter_index')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
            Profile.objects.create(
                user=user,
                first_name=self.cleaned_data['first_name'],
                middle_name=self.cleaned_data.get('middle_name',''),
                last_name=self.cleaned_data['last_name'],
                phone=self.cleaned_data['phone'],
                dob_iso=str(self.cleaned_data['dob']),
                gender=self.cleaned_data['gender'],
                random_letter_index=str(self.cleaned_data['random_letter_index']),
            )
        return user

class LoginCodeForm(forms.Form):
    username = forms.CharField()
    secret_code = forms.CharField(max_length=16)

class OTPForm(forms.Form):
    username = forms.CharField()
    otp = forms.CharField(max_length=6)

class ForgotSecretForm(forms.Form):
    username = forms.CharField()
    email = forms.EmailField()

class ProfileEditRequestForm(forms.Form):
    username = forms.CharField()
    email = forms.EmailField()

class ProfileEditForm(forms.Form):
    username = forms.CharField()
    profile_edit_key = forms.CharField()
    otp = forms.CharField(max_length=6)
    # Example: allow editing phone only (demo); can extend as needed
    phone = forms.CharField(max_length=15, required=True)
