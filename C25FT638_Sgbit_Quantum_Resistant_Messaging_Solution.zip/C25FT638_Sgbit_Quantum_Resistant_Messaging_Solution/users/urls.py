from django.urls import path
from . import views

app_name = "users"

urlpatterns = [
    
    path('', views.base, name='base'),
    path('register/', views.register, name='register'),
    path('verify/', views.verify_otp, name='verify'),
    path('login/', views.login_step1, name='login'),
    path('login/verify/', views.login_verify, name='login_verify'),
    path('logout/', views.logout_view, name='logout'),
    path('forgot-secret/', views.forgot_secret, name='forgot_secret'),
    path('profile/', views.profile, name='profile'),
    path('profile/request-edit/', views.profile_request_edit_key, name='profile_request_edit_key'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
    path('reset-secret/verify/', views.reset_secret_verify, name='reset_secret_verify'),
]
