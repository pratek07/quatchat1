from django.utils import timezone
from .models import UserSession

class SessionTrackMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        response = self.get_response(request)
        # logout tracking: when session flushed, finalize last session
        if request.path.endswith('/users/logout/'):
            if request.user.is_authenticated:
                UserSession.end_last_session(request.user)
        return response
