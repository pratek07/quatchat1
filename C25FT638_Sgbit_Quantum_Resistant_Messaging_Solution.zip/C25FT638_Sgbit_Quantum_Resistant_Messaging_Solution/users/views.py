# users\views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.utils import timezone
from django.conf import settings
from django.core.mail import send_mail
from .forms import RegisterForm, LoginCodeForm, OTPForm, ForgotSecretForm, ProfileEditRequestForm, ProfileEditForm
from .models import Profile, OTP, UserSession
from .utils import build_secret_code, secret_hints
import secrets
# users/views.py
from datetime import timedelta

from django.db import transaction
from django.utils import timezone
from django.core.exceptions import ValidationError
# helpers in users/views.py
def _now():
    return timezone.now()

def _otp_qs(user, purpose):
    from .models import OTP
    return OTP.objects.filter(user=user, purpose=purpose, used=False).order_by('-created_at')

User = get_user_model()

def base(request):
    return render(request, 'base.html')

def _send_otp(user, purpose):
    # basic throttle: last OTP within 45s -> deny
    last = _otp_qs(user, purpose).first()
    if last and (_now() - last.created_at).total_seconds() < 45:
        return last  # silently reuse to avoid spamming

    code = f"{secrets.randbelow(1_000_000):06d}"
    # mark older ones unusable
    _otp_qs(user, purpose).update(used=True)

    otp = OTP.objects.create(
        user=user,
        code=code,
        purpose=purpose,
        expires_at=_now() + timedelta(minutes=5),
    )
    try:
        send_mail(
            subject=f"[SecureAuth] Your OTP for {purpose}",
            message=f"Your OTP is {code}. It expires in 5 minutes.",
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[user.email],
            fail_silently=False,
        )
    except Exception:
        # you can log this; in prod you might keep fail_silently=True and add Sentry logging
        pass
    return otp


from django.contrib import messages
from django.shortcuts import render, redirect

from django.core.mail import send_mail
from django.conf import settings

# def _send_secret_email(user, secret_code, profile_edit_key, hints_text):
#     subject = "Your Secret Login Code (Keep this safe)"
#     body = (
#         f"Hi {user.get_full_name() or user.username},\n\n"
#         "Your account has been verified successfully.\n\n"
#         "🔑 Secret Login Code:\n"
#         f"{secret_code}\n\n"
#         "💡 Saved Hints:\n"
#         f"{hints_text or 'No hints saved.'}\n\n"
#         "🔧 Profile Edit Link (keep private):\n"
#         f"{getattr(settings, 'SITE_URL', 'http://localhost:8000')}"
#         f"/users/profile/edit/{profile_edit_key}/\n\n"
#         "If you didn’t request this, please contact support immediately."
#     )
#     send_mail(subject, body, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=False)

from django.core.mail import EmailMessage

def _send_secret_email(user, secret_code, profile_edit_key, hints_text):
    subject = "Your Secret Login Code (Keep this safe)"
    body = (
        f"Hi {user.get_full_name() or user.username},\n\n"
        "Your account has been verified successfully.\n\n"
        "🔑 Secret Login Code:\n"
        f"{secret_code}\n\n"
        "💡 Saved Hints:\n"
        f"{hints_text or 'No hints saved.'}\n\n"
        "🔧 Profile Edit Link (keep private):\n"
        f"{getattr(settings, 'SITE_URL', 'http://localhost:8000')}/users/profile/edit/{profile_edit_key}/\n\n"
        "If you didn’t request this, please contact support immediately."
    )

    email = EmailMessage(
        subject=subject,
        body=body,
        from_email=settings.DEFAULT_FROM_EMAIL,
        to=[user.email],
    )
    email.content_subtype = "plain"  # ensures plain text
    email.encoding = 'utf-8'
    email.send(fail_silently=False)

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            # build and store hints
            prof = user.profile
            code = build_secret_code(
                prof.first_name, prof.dob_iso, prof.phone, prof.gender, prof.random_letter_index
            )
            hints = secret_hints(
                prof.first_name, prof.dob_iso, prof.phone, prof.gender, prof.random_letter_index
            )
            prof.secret_code_hints = "\n".join([f"Hint {i+1}: {h}" for i, h in enumerate(hints)])
            # generate profile edit key
            prof.profile_edit_key = secrets.token_urlsafe(16)
            prof.save()

            # Stash plaintext secret in session so we can email it *after* OTP verification
            request.session['pending_secret_code'] = code

            _send_otp(user, 'register')
            request.session['verify_user'] = user.username
            messages.success(
                request,
                "Registration successful. An OTP was sent to your email to verify your account."
            )
            return redirect('users:verify')
    else:
        form = RegisterForm()
    return render(request, 'users/register.html', {'form': form})


from django.contrib import messages
from django.shortcuts import render, redirect

def verify_otp(request):
    username = request.session.get('verify_user')
    if request.method == 'POST':
        form = OTPForm(request.POST)
        if form.is_valid():
            uname = form.cleaned_data['username']
            otp_code = form.cleaned_data['otp']
            try:
                user = User.objects.get(username=uname)
            except User.DoesNotExist:
                messages.error(request, "Invalid user.")
                return redirect('users:verify')

            otp = OTP.objects.filter(user=user, purpose='register').order_by('-created_at').first()
            if otp and otp.is_valid() and otp.code == otp_code:
                otp.used = True
                otp.save()

                # Pull plaintext secret from session (preferred), else recompute
                secret_plain = request.session.pop('pending_secret_code', None)
                prof = user.profile
                if not secret_plain:
                    secret_plain = build_secret_code(
                        prof.first_name, prof.dob_iso, prof.phone, prof.gender, prof.random_letter_index
                    )

                # Send email with the secret code + hints + edit link
                _send_secret_email(
                    user=user,
                    secret_code=secret_plain,
                    profile_edit_key=prof.profile_edit_key,
                    hints_text=prof.secret_code_hints
                )

                # Clean up the username marker — verification flow completed
                request.session.pop('verify_user', None)

                messages.success(
                    request,
                    "Email verified! We just emailed your secret login code and profile edit link. "
                    "You can now log in using your secret code."
                )
                return redirect('users:login')
            else:
                messages.error(request, "Invalid or expired OTP.")
    else:
        form = OTPForm(initial={'username': username})
    return render(request, 'users/verify.html', {'form': form})


def login_step1(request):
    if request.method == 'POST':
        form = LoginCodeForm(request.POST)
        if form.is_valid():
            uname = form.cleaned_data['username']
            code = form.cleaned_data['secret_code']
            try:
                user = User.objects.get(username=uname)
                prof = user.profile
            except (User.DoesNotExist, Profile.DoesNotExist):
                messages.error(request, "Invalid credentials.")
                return redirect('users:login')
            expected = build_secret_code(prof.first_name, prof.dob_iso, prof.phone, prof.gender, prof.random_letter_index)
            if expected != code:
                messages.error(request, "Invalid secret code.")
                return redirect('users:login')
            _send_otp(user, 'login')
            request.session['login_user'] = uname
            messages.info(request, "We sent an OTP to your email. Enter it to finish login.")
            return redirect('users:login_verify')
    else:
        form = LoginCodeForm()
    return render(request, 'users/login.html', {'form': form})

def login_verify(request):
    username = request.session.get('login_user')
    if request.method == 'POST':
        form = OTPForm(request.POST)
        if form.is_valid():
            uname = form.cleaned_data['username']
            otp_code = form.cleaned_data['otp']
            try:
                user = User.objects.get(username=uname)
            except User.DoesNotExist:
                messages.error(request, "Invalid user.")
                return redirect('users:login_verify')
            otp = OTP.objects.filter(user=user, purpose='login').order_by('-created_at').first()
            if otp and otp.is_valid() and otp.code == otp_code:
                otp.used = True
                otp.save()
                login(request, user)
                UserSession.start_session(user)
                messages.success(request, "Logged in successfully.")
                return redirect('messaging:dashboard')
            else:
                messages.error(request, "Invalid or expired OTP.")
    else:
        form = OTPForm(initial={'username': username})
    return render(request, 'users/login_verify.html', {'form': form})

def logout_view(request):
    if request.user.is_authenticated:
        from .models import UserSession
        UserSession.end_last_session(request.user)
        logout(request)
    return redirect('users:login')

# users/views.py (replace your forgot_secret with this)
def forgot_secret(request):
    if request.method == 'POST':
        form = ForgotSecretForm(request.POST)
        if form.is_valid():
            uname = form.cleaned_data['username']
            email = form.cleaned_data['email']
            try:
                user = User.objects.get(username=uname, email=email)
                prof = user.profile
            except (User.DoesNotExist, Profile.DoesNotExist):
                messages.error(request, "No matching account.")
                return redirect('users:forgot_secret')

            # 1) Regenerate the selector that affects the secret
            import random
            prof.random_letter_index = random.randint(1, 26)   # keep it as an int if the model field is int
            # 2) Refresh hints for the new secret
            hints = secret_hints(prof.first_name, prof.dob_iso, prof.phone, prof.gender, prof.random_letter_index)
            prof.secret_code_hints = "\n".join([f"Hint {i+1}: {h}" for i, h in enumerate(hints)])
            prof.save()

            # 3) Generate OTP for reset flow
            _send_otp(user, 'reset_secret')

            # 4) Point the user to a dedicated verify step
            request.session['reset_user'] = user.username
            messages.success(request, "We sent an OTP to your email. Enter it to confirm the reset.")
            return redirect('users:reset_secret_verify')
    else:
        form = ForgotSecretForm()
    return render(request, 'users/forgot_secret.html', {'form': form})

# users/views.py (add this)
def reset_secret_verify(request):
    username = request.session.get('reset_user')
    if request.method == 'POST':
        form = OTPForm(request.POST)
        if form.is_valid():
            uname = form.cleaned_data['username']
            otp_code = form.cleaned_data['otp']
            try:
                user = User.objects.get(username=uname)
            except User.DoesNotExist:
                messages.error(request, "Invalid user.")
                return redirect('users:reset_secret_verify')

            otp = OTP.objects.filter(user=user, purpose='reset_secret').order_by('-created_at').first()
            if otp and otp.is_valid() and otp.code == otp_code:
                otp.used = True
                otp.save()

                # Recompute the new secret from the (already updated) profile
                prof = user.profile
                secret_plain = build_secret_code(
                    prof.first_name, prof.dob_iso, prof.phone, prof.gender, prof.random_letter_index
                )

                # Email the new secret + hints + profile edit link
                _send_secret_email(
                    user=user,
                    secret_code=secret_plain,
                    profile_edit_key=prof.profile_edit_key,
                    hints_text=prof.secret_code_hints
                )

                # Clean up the session marker
                request.session.pop('reset_user', None)

                messages.success(request, "Secret reset confirmed. We’ve emailed your new secret login code.")
                return redirect('users:login')
            else:
                messages.error(request, "Invalid or expired OTP.")
    else:
        form = OTPForm(initial={'username': username})
    # Reuse your verify template
    return render(request, 'users/verify.html', {'form': form})


def profile(request):
    if not request.user.is_authenticated:
        return redirect('users:login')
    prof = request.user.profile
    return render(request, 'users/profile.html', {'prof': prof})

def profile_request_edit_key(request):
    # For demo, re-send existing key by email + OTP
    if not request.user.is_authenticated:
        return redirect('users:login')
    user = request.user
    prof = user.profile
    _send_otp(user, 'profile_edit')
    send_mail(
        subject="[SecureAuth] Profile edit key",
        message=f"Your profile edit key is: (keep secret)\n\n{prof.profile_edit_key}",
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        fail_silently=True,
    )
    messages.info(request, "We emailed your profile edit key and an OTP. Use both to edit profile.")
    return redirect('users:profile')

def profile_edit(request):
    if request.method == 'POST':
        form = ProfileEditForm(request.POST)
        if form.is_valid():
            uname = form.cleaned_data['username']
            key = form.cleaned_data['profile_edit_key']
            otp_code = form.cleaned_data['otp']
            new_phone = form.cleaned_data['phone']
            try:
                user = User.objects.get(username=uname)
                prof = user.profile
            except (User.DoesNotExist, Profile.DoesNotExist):
                messages.error(request, "Invalid user.")
                return redirect('users:profile_edit')
            if prof.profile_edit_key != key:
                messages.error(request, "Invalid profile edit key.")
                return redirect('users:profile_edit')
            otp = OTP.objects.filter(user=user, purpose='profile_edit').order_by('-created_at').first()
            if not (otp and otp.is_valid() and otp.code == otp_code):
                messages.error(request, "Invalid or expired OTP.")
                return redirect('users:profile_edit')
            otp.used = True
            otp.save()
            prof.phone = new_phone
            prof.save()
            messages.success(request, "Profile updated.")
            return redirect('users:profile')
    else:
        form = ProfileEditForm()
    return render(request, 'users/profile_edit.html', {'form': form})
