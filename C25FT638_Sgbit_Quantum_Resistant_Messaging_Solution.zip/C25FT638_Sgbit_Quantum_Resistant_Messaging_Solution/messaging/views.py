# users/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required

from django.db.models import Q
from django.conf import settings

from django.contrib.auth import get_user_model

from .forms import *
from .models import *
from messaging.models import *

# dashboard
# users/views.py (add this code)
import json
from collections import Counter, defaultdict
from django.utils import timezone
from datetime import timedelta

from .crypto_utils import secure_receive_message, CryptoConfigError

# users/views.py (add imports near top)
from collections import Counter
from django.contrib.auth.decorators import login_required
from django.db.models import Q
import json

from .models import Message

@login_required
def dashboard(request):
    """
    Security dashboard:
    - Charts: PQ-KEM vs classical, PQ-sign vs classical, Symmetric algorithm usage
    - Roles/importance & attacker challenges (static explainer blocks)
    - Metadata meaning (inspector of recent messages)
    """
    # Only messages the current user is involved in
    msgs = Message.objects.filter(
        Q(sender=request.user) | Q(receiver=request.user)
    ).order_by('-timestamp')

    total_msgs = msgs.count()

    # Defensive extraction
    def meta(msg):
        return msg.encrypted_meta or {}

    # Aggregates
    pq_kem_count = sum(1 for m in msgs if meta(m).get('pq_kem') is True)
    classical_kem_count = sum(1 for m in msgs if meta(m).get('pq_kem') is False)

    pq_sign_count = sum(1 for m in msgs if meta(m).get('pq_sign') is True)
    classical_sign_count = sum(1 for m in msgs if meta(m).get('pq_sign') is False)

    sym_counter = Counter((meta(m).get('sym_algo') or 'UNKNOWN') for m in msgs)
    # Lock the order we want to display
    sym_labels = ['AES', 'CHACHA20', 'UNKNOWN']
    sym_data = [sym_counter.get(lbl, 0) for lbl in sym_labels]

    # A small metadata inspector (latest 10 messages)
    recent_meta = []
    for m in msgs[:10]:
        em = meta(m)
        recent_meta.append({
            "id": m.id,
            "when": m.timestamp.strftime("%Y-%m-%d %H:%M"),
            "from": getattr(m.sender, "name", str(m.sender)),
            "to": getattr(m.receiver, "name", str(m.receiver)) if m.receiver else "Group",
            "pq_kem": em.get("pq_kem"),
            "pq_sign": em.get("pq_sign"),
            "sym_algo": em.get("sym_algo"),
            "kem_ct": (em.get("kem_ct") or "")[:24] + ("..." if em.get("kem_ct") else ""),
            "nonce": (em.get("nonce") or "")[:16] + ("..." if em.get("nonce") else ""),
            "ciphertext": (em.get("ciphertext") or "")[:24] + ("..." if em.get("ciphertext") else ""),
            "hash_hex": (em.get("hash_hex") or "")[:16] + ("..." if em.get("hash_hex") else ""),
            "signature": (em.get("signature") or "")[:24] + ("..." if em.get("signature") else ""),
            "signer_pk": (em.get("signer_pk") or "")[:24] + ("..." if em.get("signer_pk") else ""),
        })

    context = {
        "total_msgs": total_msgs,
        "pq_kem_count": pq_kem_count,
        "classical_kem_count": classical_kem_count,
        "pq_sign_count": pq_sign_count,
        "classical_sign_count": classical_sign_count,
        "sym_labels": json.dumps(sym_labels),
        "sym_data": json.dumps(sym_data),
        "recent_meta": recent_meta,
        # Static role/importance text for the dashboard
        "algo_roles": [
            {
                "name": "Kyber (KEM)",
                "role": "Securely exchanges the session key (post-quantum).",
                "importance": "Prevents future decryption (harvest-now, decrypt-later).",
                "hacker": "Must solve lattice MLWE → currently infeasible even with quantum."
            },
            {
                "name": "Dilithium (Signature)",
                "role": "Proves sender authenticity; prevents forgery (post-quantum).",
                "importance": "Long-term authenticity of software/messages.",
                "hacker": "Forge lattice signature → infeasible with current knowledge."
            },
            {
                "name": "AES-GCM",
                "role": "Fast symmetric encryption; integrity via AEAD tag.",
                "importance": "Protects bulk data in motion and at rest.",
                "hacker": "Brute-force 2^256 (impossible); pitfalls: key/nonce reuse, side-channels."
            },
            {
                "name": "ChaCha20-Poly1305",
                "role": "Stream cipher + MAC, constant-time; great on mobile CPUs.",
                "importance": "Performance + side-channel resistance.",
                "hacker": "Brute-force key only; constant-time design thwarts timing attacks."
            },
            {
                "name": "SHA3-256",
                "role": "Integrity hash; input to signatures.",
                "importance": "Detects any tampering reliably.",
                "hacker": "Collisions/preimages computationally infeasible (e.g., 2^128 for collisions)."
            },
            {
                "name": "ECC/Ed25519 (fallback)",
                "role": "Fast classical signatures where PQ not available.",
                "importance": "Widely deployed; easy integration.",
                "hacker": "ECDLP hard on classical; vulnerable to quantum (Shor) in the future."
            },
            {
                "name": "RSA (legacy)",
                "role": "Classical signatures/encryption; legacy compatibility.",
                "importance": "Interoperability with older systems.",
                "hacker": "Factoring n; strong today at ≥2048 bits, broken by future quantum."
            }
        ],
        "meta_explain": [
            {"key": "pq_kem", "meaning": "True if post-quantum KEM (Kyber) was used; False means classical fallback/simulation."},
            {"key": "pq_sign", "meaning": "True if post-quantum signature (Dilithium) was used; False means Ed25519/RSA."},
            {"key": "sym_algo", "meaning": "Symmetric cipher used to encrypt the message payload (AES or CHACHA20)."},
            {"key": "kem_ct", "meaning": "KEM ciphertext sent to the receiver so they can derive the same session key."},
            {"key": "nonce", "meaning": "Unique per-message number for AEAD; never reuse with the same key."},
            {"key": "ciphertext", "meaning": "The encrypted message bytes; looks like random data."},
            {"key": "hash_hex", "meaning": "SHA3-256 digest of plaintext; used for signing and integrity checks."},
            {"key": "signature", "meaning": "Digital signature over hash; proves the sender and prevents forgery."},
            {"key": "signer_pk", "meaning": "Public key needed to verify the signature (included for self-contained verification)."},
            {"key": "ss", "meaning": "Shared secret (DEMO ONLY). Do NOT store in production systems."},
        ],
    }
    return render(request, "users/dashboard.html", context)

# chat
from django.db.models import Q
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from django.db.models import Exists, OuterRef

# users/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Exists, OuterRef
from django.contrib import messages
from django.contrib.auth import get_user_model

from .models import Message
from .crypto_utils import (
    secure_send_plaintext, secure_receive_message,
    kem_generate, generate_sign_keypair,
    derive_sym_key, decrypt_aes_gcm, decrypt_chacha20,
    CryptoConfigError,
)

User = get_user_model()

def _ensure_user_keys(user: User):
    changed = False
    if not getattr(user, "kem_pk", None) or not getattr(user, "kem_sk", None):
        kem = kem_generate()
        user.kem_pk, user.kem_sk = kem["pk"], kem["sk"]
        changed = True
    if not getattr(user, "sign_pk", None) or not getattr(user, "sign_sk", None):
        sig = generate_sign_keypair()
        user.sign_pk, user.sign_sk = sig["pk"], sig["sk"]
        changed = True
    if changed:
        user.save()

def _decrypt_self_sent(meta: dict) -> str:
    if not meta:
        return "(unable to decrypt)"
    ss_b64 = meta.get("ss")
    if not ss_b64:
        return "(sent – encrypted stored)"
    key = derive_sym_key(ss_b64)
    algo = (meta.get("sym_algo") or "AES").upper()
    if algo == "AES":
        pt = decrypt_aes_gcm(meta["nonce"], meta["ciphertext"], key)
    elif algo == "CHACHA20":
        pt = decrypt_chacha20(meta["nonce"], meta["ciphertext"], key)
    else:
        return "(unknown cipher)"
    return pt.decode("utf-8", errors="replace")

# users/views.py (add this)
import json
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.db.models import Q
from .models import Message

User = get_user_model()

def _pretty_json(value) -> str:
    if not value:
        return "{}"
    try:
        return json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False)
    except Exception:
        # Fallback if value isn’t valid JSON (shouldn’t happen with JSONField)
        return str(value)

@login_required
def messages_all(request):
    """
    Admin-style list for all messages with meta JSON pretty-printed.
    Filters: q (text), sender, receiver, unread, group
    """
    q = (request.GET.get("q") or "").strip()
    sender_id = request.GET.get("sender") or ""
    receiver_id = request.GET.get("receiver") or ""
    unread = request.GET.get("unread")  # "on" or None
    group = request.GET.get("group")    # "on" or None

    qs = Message.objects.select_related("sender", "receiver").all().order_by("-timestamp")

    if q:
        qs = qs.filter(
            Q(text__icontains=q) |
            Q(sender__username__icontains=q) |
            Q(sender__first_name__icontains=q) |
            Q(sender__last_name__icontains=q) |
            Q(receiver__username__icontains=q) |
            Q(receiver__first_name__icontains=q) |
            Q(receiver__last_name__icontains=q)
        )

    if sender_id.isdigit():
        qs = qs.filter(sender_id=int(sender_id))
    if receiver_id.isdigit():
        qs = qs.filter(receiver_id=int(receiver_id))

    if unread == "on":
        qs = qs.filter(is_read=False)
    if group == "on":
        qs = qs.filter(is_group_message=True)

    paginator = Paginator(qs, 25)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    # Build display rows with pretty JSON
    rows = []
    for m in page_obj.object_list:
        rows.append({
            "id": m.id,
            "sender": m.sender,
            "receiver": m.receiver,
            "text": m.text,
            "has_image": bool(m.image),
            "image_url": m.image.url if m.image else None,
            "timestamp": m.timestamp,
            "is_group_message": m.is_group_message,
            "is_read": m.is_read,
            "meta_pretty": _pretty_json(m.encrypted_meta),
        })

    users = User.objects.order_by("first_name", "last_name", "username")

    legend_html = (
        'pq_kem = Post-Quantum KEM used; pq_sign = Post-Quantum signature used; '
        'sym_algo = AES/ChaCha20; nonce = unique per message; kem_ct = KEM ciphertext; '
        'hash_hex = SHA3-256 of plaintext; ss = shared secret (DEMO ONLY — do not store in production).'
    )

    return render(request, "users/messages_all.html", {
        "rows": rows,
        "page_obj": page_obj,
        "users": users,
        "q": q,
        "sender_id": sender_id,
        "receiver_id": receiver_id,
        "unread": unread == "on",
        "group": group == "on",
        "legend_html": legend_html,
    })


@login_required
def messenger(request, user_id=None):
    """
    Single-page Messenger:
    - Left: searchable user list with unread badges
    - Right: chat thread + composer (when a user is selected)
    """
    # ---- Left pane (users + search) ----
    query = request.GET.get('q', '').strip()
    users = User.objects.exclude(id=request.user.id)

    if query:
        users = users.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(email__icontains=query)
        )

    unread_exists = Message.objects.filter(
        sender=OuterRef('pk'),
        receiver=request.user,
        is_read=False
    )
    users = users.annotate(has_unread=Exists(unread_exists)).order_by('first_name', 'last_name', 'username')

    # ---- Right pane (selected chat) ----
    other_user = None
    display_items = []
    sym_default = (request.POST.get('sym_algo') or request.GET.get('sym', 'AES')).upper()

    if user_id:
        other_user = get_object_or_404(User, id=user_id)
        _ensure_user_keys(request.user)
        _ensure_user_keys(other_user)

        # Submit new message
        if request.method == 'POST':
            text = (request.POST.get('text') or '').strip()
            sym_algo = (request.POST.get('sym_algo') or 'AES').upper()
            if text:
                try:
                    meta = secure_send_plaintext(
                        plaintext=text,
                        recipient_kem_pk_b64=other_user.kem_pk,
                        sender_sign_sk_b64=request.user.sign_sk,
                        sender_sign_pk_b64=request.user.sign_pk,
                        use_pq_sign=True,
                        sym_algo=sym_algo
                    )
                    Message.objects.create(
                        sender=request.user,
                        receiver=other_user,
                        text='',
                        encrypted_meta=meta
                    )
                except CryptoConfigError as e:
                    messages.error(request, f"Crypto configuration error: {e}")
                except Exception as e:
                    messages.error(request, f"Unexpected crypto error: {e}")
                return redirect('messaging:chat', user_id=other_user.id)

        # Conversation (newest first in DB; we’ll show oldest->newest in UI)
        qs = Message.objects.filter(
            (Q(sender=request.user) & Q(receiver=other_user)) |
            (Q(sender=other_user) & Q(receiver=request.user))
        ).order_by('-timestamp')

        # Mark other_user -> me as read
        Message.objects.filter(sender=other_user, receiver=request.user, is_read=False).update(is_read=True)

        # Build display list
        for msg in qs:
            meta = msg.encrypted_meta or {}
            entry = {
                'timestamp': msg.timestamp,
                'from': msg.sender,
                'meta': meta,
                'image': getattr(msg, "image", None),
            }
            try:
                if msg.sender == request.user:
                    entry['plaintext'] = _decrypt_self_sent(meta)
                    entry['signature_valid'] = None
                else:
                    fallback_pk = msg.sender.sign_pk if getattr(msg.sender, "sign_pk", None) else None
                    plaintext, sig_ok = secure_receive_message(
                        recipient_kem_sk_b64=request.user.kem_sk,
                        stored_meta=meta,
                        fallback_signer_pk_b64=fallback_pk
                    )
                    entry['plaintext'] = plaintext
                    entry['signature_valid'] = sig_ok
            except Exception as e:
                entry['plaintext'] = "(decryption failed)"
                entry['signature_valid'] = False
                entry['decrypt_error'] = str(e)
            display_items.append(entry)

        # Reverse to show Oldest -> Newest top-to-bottom in the scroll area
        display_items.reverse()

    context = {
        'users': users,
        'query': query,
        'receiver': other_user,
        'messages_view': display_items,
        'sym_default': sym_default,
    }
    return render(request, 'users/messenger.html', context)


# Feedback

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .forms import FeedbackForm
from .models import Feedback

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import Feedback
from .forms import FeedbackForm  # Make sure this form uses 'message' field
from django.contrib import messages

@login_required
def feedback_view(request):
    if request.method == 'POST':
        # Create form manually since the HTML form doesn't use Django's form rendering
        message = request.POST.get('text')  # textarea name is 'text'
        if message:
            Feedback.objects.create(user=request.user, message=message)
            return redirect('messaging:feedback')  # redirect to avoid resubmission
        else:
            messages.error(request, "Feedback message cannot be empty.")
    
    # Get user's past feedback
    feedbacks = Feedback.objects.filter(user=request.user).order_by('created_at')
    
    return render(request, 'feedback/feedback.html', {
        'feedbacks': feedbacks
    })


@login_required
def view_feedbacks(request):
    if request.user.is_superuser:
        feedbacks = Feedback.objects.all().order_by('-created_at')
        return render(request, 'feedback/view_feedbacks.html', {'feedbacks': feedbacks})
    else:
        return redirect('messaging:dashboard')

# myapp/views.py
# myapp/views.py

# views.py
# myapp/views.py



