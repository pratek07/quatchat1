# users/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from .views import *
from django.conf import settings
from django.conf.urls.static import static

app_name = "messaging"

urlpatterns = [
    path('dashboard/', dashboard, name='dashboard'),
    # Unified messenger page (user list + chat)
    path("messenger/", messenger, name="list"),

    # Chat with a specific user (right panel open)
    path("messenger/<int:user_id>/", messenger, name="chat"),
    
    path("messages/", messages_all, name="messages_all"),
    path('feedback/', feedback_view, name='feedback'),
    path('feedbacks/', view_feedbacks, name='view_feedbacks'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

