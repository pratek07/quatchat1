# SecureAuth (Django + SQLite + Bootstrap)

Two-factor login via **16-char secret code** + **email OTP**. User details (fname, lname, mname, phone, dob, gender) are stored **encrypted** in SQLite using Fernet. Only **username** and **code hints** remain unencrypted (per spec).

Features:
- Register with custom fields (plus email for OTP).
- Deterministic 16-char secret code composition (not stored; only hints are saved).
- OTP verification on registration, login, profile edit, and secret reset.
- Login requires secret code (no username in the code) + OTP.
- Track login/logout and session duration.
- Generate synthetic transaction datasets (50, 75, 100, 150) with anomalies: identity theft, money laundering, credit card fraud, account takeover.
- Upload CSV and run analytics + ML (Decision Tree, Random Forest, XGBoost).
- Forgot-secret flow regenerates the random letter component; hints are updated.
- Profile is read-only. Editing requires **profile edit key** + OTP.

## Quickstart

```bash
# 1) Create venv, install deps, migrate, and run
bash run_local.sh
# Then open http://127.0.0.1:8000/
```

If you need real emails, set SMTP in `.env` (copy `.env.example` to `.env`). Otherwise, OTPs print to console backend.

## Secret Code Pattern

`aaaa b c c mm ppppp g` → 16 chars total:
- `aaaa`: first 4 of first name, lowercase (pad with `x` if short)
- `b`: last 2 digits of birth year
- `c c`: the letter for your chosen number (1–26 → A–Z), repeated twice
- `mm`: two-digit birth month
- `ppppp`: last 5 digits of phone
- `g`: first letter of gender (M/F/O)

We never store the code itself, only **hints**.

## CSV Columns (upload)
`account_number, credit_card_number, amount, currency, timestamp, merchant, category, label`

## Admin
Create a superuser:
```bash
source .venv/bin/activate
python manage.py createsuperuser
```

## Notes
- All custom personal fields are encrypted at rest via a custom field wrapper.
- Username and `secret_code_hints` are left unencrypted as required.
- Models and pages are minimal Bootstrap and intended for local/demo usage.
