from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('users/', include('users.urls')),
    path('tx/', include('transactions.urls')),
    path('msg/', include('messaging.urls')),
    path('grpmsg/', include('group_messaging.urls')),
    path('', RedirectView.as_view(pattern_name='users:base', permanent=False)),
]
